
$('#btn').click(function(){
	$('.about').css('background-color', 'pink');
});