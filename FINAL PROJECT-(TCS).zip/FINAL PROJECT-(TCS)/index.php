<!DOCTYPE html>
<html>
<head>
        <title>Admin Page</title>
        <style>   
        /* Style for all elements */
        * {
                box-sizing: border-box;
        }

        /* Style the body */
        body {
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
        }


        /* Header/logo Title */
        .header {
                padding: 3em;
                text-align: center;
                background: #1abc9c;
                color: white;
        }

        /* Increase the font size of the heading */
        .header h1 {
                font-size: 40px;
        }

        /* Sticky navbar */
        .navbar {
                overflow: hidden;
                background-color: #333;
                position: sticky;
                position: -webkit-sticky;
                top: 0;
        }

        /* Style the navigation bar links */
        .navbar a {
                float: left;
                display: block;
                color: white;
                text-align: center;
                padding: 14px 20px;
                text-decoration: none;
        }

        /* Change color on hover */
        .navbar a:hover {
                background-color: #ddd;
                color: black;
        }

        /* Active/current link */
        .navbar a.active {
                background-color: #666;
                color: white;
        }

        /* Main column */
        .main {   
                background-color: white;
                padding: 20px 5em;
                margin-bottom: 20px;
        }

        /* Footer */
        .footer {
                padding: 20px;
                text-align: center;
                background: #ddd;
        }

        /* Responsive layout */
        @media screen and (max-width: 700px) {
                .main {   
                        padding: 20px;
                }
        }

        @media screen and (max-width: 400px) {
                .navbar a {
                float: none;
                width: 100%;
                }
        }

        /* Styling the input tags */
        input[type=text], select {
                width: 100%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
        }

        input[type=submit] {
                width: 100%;
                background-color: #4CAF50;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
        }

        input[type=submit]:hover {
                background-color: #45a049;
        }
        </style>
</head>

<body>

        <div class="header">
                <h1>Project for TCS</h1>
                <p>Admin Page for Index.php</p>
        </div>

        <div class="navbar">
                <a href="#" class="active">Home</a>
                <a href="#">About</a>
                <a href="#">Contact us</a>
        </div>

        <div class="main">
                <h3>Form for Changing the Contents in Index Page</h3>

                <div>
                        <form action="index.php" method="GET">
                        <label for="title">Title</label>
                        <input type="text" id="title" name="title" placeholder="Title for Index Page...">
                        <br><br>
                        <label for="welcome">Welcome Word</label>
                        <input type="text" id="welcome" name="welcome" placeholder="Welcome word for Index Page...">
                        <br><br>
                        <label for="picture">Picture (with extension)</label>
                        <input type="text" id="picture" name="picture" placeholder="E.g, image2.jpg">
                        <br><br>
                        <label for="picture_desc">Picture Description</label>
                        <input type="text" id="picture_desc" name="picture_desc" placeholder="Welcome word for Index Page...">
                                <br><br>
                        <input type="submit" name="submit" value="Submit">
                        </form>
                </div>
        </div>

        <div class="footer">
        <h2>Web Design Project</h2>
        <h3>Jaskirat Singh</h3>
        </div>

</body>
</html>