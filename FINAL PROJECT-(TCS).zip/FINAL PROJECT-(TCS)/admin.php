<?php
$title = "DEFAULT TITLE OF INDEX";
$welcome = "Welcome to the website! (default)";
$picture = "default_image2.jpg";
$picture_desc = "Default Description of the Picture.";

if(isset($_GET['submit'])) {
        if($_GET['title']!="") {
                $title = $_GET['title'];
        }

        if($_GET['welcome']!="") {
                $welcome = $_GET['welcome'];
        }

        if($_GET['picture']!="") {
                $picture = $_GET['picture'];
        }

        if($_GET['picture_desc']!="") {
                $picture_desc = $_GET['picture_desc'];
        }
}
?>

<!DOCTYPE html>
<html>
<head>
        <title>Website Title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>

        /* Style for all elements */
        * {
                box-sizing: border-box;
        }

        /* Style the body */
        body {
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
        }

        /* Header/logo Title */
        .header {
                padding: 3em;
                text-align: center;
                background: #1abc9c;
                color: white;
        }

        .header h1 {
                font-size: 40px;
        }

        /* Sticky navbar */
        .navbar {
                overflow: hidden;
                background-color: #333;
                position: sticky;
                position: -webkit-sticky;
                top: 0;
        }

        /* Style the navigation bar links */
        .navbar a {
                float: left;
                display: block;
                color: white;
                text-align: center;
                padding: 14px 20px;
                text-decoration: none;
        }

        /* Change color on hover */
        .navbar a:hover {
                background-color: #ddd;
                color: black;
        }

        /* Active/current link */
        .navbar a.active {
                background-color: #666;
                color: white;
        }

        /* Main column */
        .main {   
                background-color: white;
                padding: 20px 5em;
        }

        /* Fake image, just for this example */
        img {
                background-color: #aaa;
                width: 50%;
                
                
        }

        /* Footer */
        .footer {
                padding: 20px;
                text-align: center;
                background: #ddd;
        }

        /* Responsive layout */
        @media screen and (max-width: 700px) {
                .main {   
                        padding: 20px;
                }
        }

        @media screen and (max-width: 400px) {
                .navbar a {
                float: none;
                width: 100%;
                }
        }
        </style>
</head>

<body>

        <div class="header">
                <h1>Website</h1>
                <p>A Dummy website created</p>
        </div>

        <div class="navbar">
                <a href="#" class="active">Home</a>
                <a href="#">About</a>
                <a href="#">Contact us</a>
        </div>

        <div class="main">
        <h2> <?php echo($title); ?> </h2>
        <h4> <?php echo($welcome); ?> </h4>
        <img style="height:200px;" src=" <?php echo($picture); ?> ">
        <p><b><?php echo($picture_desc); ?></b></p>
        <br>
        <p>Canada is a country that has much to offer visitors, from island sights to scenic mountain waterfalls. 
        Stretching from the Atlantic to the Pacific coasts, this former French and British colony has a rich heritage 
        from the North Coast Indians of British Columbia to the French explorers of Quebec.</p>
        <p>The Calgary Stampede, one of the most famous rodeos in the world, traces its origins back to the traveling 
        wild west shows of the late 1800s and early 1900s. The Stampede has grown over the years, today attracting the 
        best cowboys in the world who compete for $2 million in prize money. Other activities include live concerts, 
        a carnival, lots of food and dancing as this Canadian city hosts the best in the west.</p>
        </div>

        <div class="footer">
                <h2>Web Design Project</h2>
                <h3>Jaskirat Singh</h3>
        </div>

</body>
</html>